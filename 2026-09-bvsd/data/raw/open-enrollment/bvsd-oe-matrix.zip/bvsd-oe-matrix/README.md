# BVSD Open Enrollment Pattern Matrices, 2016-17 to 2025-26

`extract_matrices.py` downloads the Elementary, Middle, and High "Enrollment
Pattern Matrix" PDFs from the BVSD Planning and Engineering page, parses each
one-page table with pdfplumber, and writes tidy CSVs to `data/processed/`.

Run: `python extract_matrices.py` (needs pandas, pdfplumber, tabulate).

Edge direction: `source` = neighborhood attendance area where students live,
`target` = school they attend. In the PDFs the areas are columns and the
schools are rows. Pseudo-sources `OUTSIDE_DISTRICT`, `UNMATCHED_ADDRESS`, and
`PLACEMENT` carry the three right-block counts that have no area of origin.
Zero cells are dropped. Self-loops are kept and flagged.

`attending_neighborhood` in `school_summary.csv` includes students from the
"Optional" areas that name the school (source footnote: "* Note optional
enrollment areas excluded"). The matrix cells keep optional areas separate.

`crosswalk.csv` is auto-generated. Edit `canonical` by hand as needed and
re-run; the script regenerates it, so keep hand edits in a copy or extend
`canonical()` in the script.

See `data/processed/audit_report.md` for reconciliation checks.
